What `react-native` version are you using ?

What `react-native-pdf` version are you using ?

Describe your issue as precisely as possible : 
  1) Steps to reproduce the issue or to explain in which case you get the issue
  2) Interesting `logs`

Join a screenshot or video of the problem on the simulator or device ?

Show us the code you are using ? 
