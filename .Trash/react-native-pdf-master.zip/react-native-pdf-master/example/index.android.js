import React from 'react';
import { AppRegistry } from 'react-native';
import PDFExample from './PDFExample';

AppRegistry.registerComponent('pdfexample', () => PDFExample);
